package com.example.demosqlite.services;

import android.content.Context;
import android.widget.Toast;

import com.example.demosqlite.models.APIRequest.Body.deleteManyAll;
import com.example.demosqlite.models.APIRequest.Model.ModelExpenseRequest;
import com.example.demosqlite.models.APIRequest.Model.ModelTripRequest;
import com.example.demosqlite.models.APIRequest.Body.insertManyTrips;
import com.example.demosqlite.models.APIResponse.deleteMany;
import com.example.demosqlite.models.APIResponse.insertMany;
import com.example.demosqlite.models.ExpenseModel;
import com.example.demosqlite.models.TripModel;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CloudDatabaseHelper {
    Context context;

    private final String TABLE_TRIP = "TABLE_TRIP";
    private final String TABLE_EXPENSE = "TABLE_EXPENSE";
    private final String DATABASE_NAME = "NativeApp";
    private final String ClusterName = "Cluster1";

    public CloudDatabaseHelper(Context context) {
        this.context = context;
    }

    public void UploadAllTrips(List<TripModel> listTrips) {

        deleteManyAll deleteManyAll = new deleteManyAll(ClusterName, DATABASE_NAME, TABLE_TRIP, new Object());
        API.apiService.dropAllData(deleteManyAll).enqueue(new Callback<deleteMany>() {
            @Override
            public void onResponse(Call<deleteMany> call, Response<deleteMany> response) {

            }

            @Override
            public void onFailure(Call<deleteMany> call, Throwable t) {

            }
        });

        ArrayList<ModelTripRequest> newList = new ArrayList<>();
        for(TripModel trip: listTrips) {
            ModelTripRequest newTrip = new ModelTripRequest(
                    trip.getTripName(),
                    trip.getTripDest(),
                    trip.getTripStartDate(),
                    trip.getTripEndDate(),
                    trip.isRiskAssessmentChecked(),
                    trip.getTripDesc(),
                    trip.getTripImage(),
                    GetAllAvailableExpenses(trip.getTripID())
            );
            newList.add(newTrip);
        }

        insertManyTrips insertManyTrips = new insertManyTrips(
                ClusterName,
                DATABASE_NAME,
                TABLE_TRIP,
                newList
        );

        API.apiService.uploadAllTrips(insertManyTrips)
                .enqueue(new Callback<insertMany>() {
            @Override
            public void onResponse(Call<insertMany> call, retrofit2.Response<insertMany> response) {
                if (response.isSuccessful()){
                    Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Response not successful", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<insertMany> call, Throwable t) {
                Toast.makeText(context, "error call api", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private ArrayList<ModelExpenseRequest> GetAllAvailableExpenses(UUID tripID) {
        DatabaseHelper databaseHelper = new DatabaseHelper(context);
        List<ExpenseModel> allExpenses = databaseHelper.getAllExpenseByTripID(tripID.toString());

        ArrayList<ModelExpenseRequest> newListExpenses = new ArrayList<>();
        if (allExpenses.size() != 0) {
            for (ExpenseModel expense: allExpenses) {
                ModelExpenseRequest newExpense = new ModelExpenseRequest(
                        expense.getExpenseType(),
                        expense.getExpenseAmount(),
                        expense.getExpenseTime(),
                        expense.getExpenseComment()
                );
                newListExpenses.add(newExpense);
            }
        }
        return newListExpenses;
    }
}
