package com.example.demosqlite.models.APIResponse;

public class insertMany {
    String[] insertedIds;

    public String[] getInsertedIds() {
        return insertedIds;
    }

    public void setInsertedIds(String[] insertedIds) {
        this.insertedIds = insertedIds;
    }

    public insertMany(String[] insertedIds) {
        this.insertedIds = insertedIds;
    }
}
