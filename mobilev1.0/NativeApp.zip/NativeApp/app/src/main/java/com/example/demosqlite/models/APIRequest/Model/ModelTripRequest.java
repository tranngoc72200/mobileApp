package com.example.demosqlite.models.APIRequest.Model;

import java.util.ArrayList;

public class ModelTripRequest {
    //region $fields
    private String tripName;
    private String tripDest;
    private String tripStartDate;
    private String tripEndDate;
    private boolean isRiskAssessmentChecked;
    private String tripDesc;
    private byte[] tripImage;
    private ArrayList<ModelExpenseRequest> listExpenses;
    //endregion

    //region $Getter and Setter

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public String getTripDest() {
        return tripDest;
    }

    public void setTripDest(String tripDest) {
        this.tripDest = tripDest;
    }

    public String getTripStartDate() {
        return tripStartDate;
    }

    public void setTripStartDate(String tripStartDate) {
        this.tripStartDate = tripStartDate;
    }

    public String getTripEndDate() {
        return tripEndDate;
    }

    public void setTripEndDate(String tripEndDate) {
        this.tripEndDate = tripEndDate;
    }

    public boolean isRiskAssessmentChecked() {
        return isRiskAssessmentChecked;
    }

    public void setRiskAssessmentChecked(boolean riskAssessmentChecked) {
        isRiskAssessmentChecked = riskAssessmentChecked;
    }

    public String getTripDesc() {
        return tripDesc;
    }

    public void setTripDesc(String tripDesc) {
        this.tripDesc = tripDesc;
    }

    public byte[] getTripImage() {
        return tripImage;
    }

    public void setTripImage(byte[] tripImage) {
        this.tripImage = tripImage;
    }

    public ArrayList<ModelExpenseRequest> getListExpenses() {
        return listExpenses;
    }

    public void setListExpenses(ArrayList<ModelExpenseRequest> listExpenses) {
        this.listExpenses = listExpenses;
    }

    //endregion

    //region $constructor

    public ModelTripRequest(String tripName, String tripDest, String tripStartDate, String tripEndDate, boolean isRiskAssessmentChecked, String tripDesc, byte[] tripImage, ArrayList<ModelExpenseRequest> listExpenses) {
        this.tripName = tripName;
        this.tripDest = tripDest;
        this.tripStartDate = tripStartDate;
        this.tripEndDate = tripEndDate;
        this.isRiskAssessmentChecked = isRiskAssessmentChecked;
        this.tripDesc = tripDesc;
        this.tripImage = tripImage;
        this.listExpenses = listExpenses;
    }


    //endregion
}
