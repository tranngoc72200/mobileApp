package com.example.demosqlite.SharedLayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.demosqlite.R;

public class CustomListViewLayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_list_view_layout);
    }
}