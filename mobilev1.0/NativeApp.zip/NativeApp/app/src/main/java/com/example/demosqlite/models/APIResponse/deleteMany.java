package com.example.demosqlite.models.APIResponse;

public class deleteMany {
    int deletedCount;

    public int getDeletedCount() {
        return deletedCount;
    }

    public void setDeletedCount(int deletedCount) {
        this.deletedCount = deletedCount;
    }

    public deleteMany(int deletedCount) {
        this.deletedCount = deletedCount;
    }
}
